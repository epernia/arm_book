//=====[#include guards - begin]===============================================

#ifndef _HTTP_SERVER_H_
#define _HTTP_SERVER_H_

//=====[Libraries]=============================================================

//=====[Declaration of public defines]=======================================

//=====[Declaration of public data types]======================================

//=====[Declarations (prototypes) of public functions]=========================

void httpServerInit();
void httpServerUpdate();

//=====[#include guards - end]=================================================

#endif // _HTTP_SERVER_H_