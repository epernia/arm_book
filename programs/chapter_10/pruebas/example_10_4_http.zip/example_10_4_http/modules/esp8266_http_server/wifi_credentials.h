
#ifndef _WIFI_CREDENTIALS_
#define _WIFI_CREDENTIALS_

// Se deben definir los datos del nombre de la red y la contrasenia.
#define WIFI_SSID                  "TrenesAr"     // Setear Red Wi-Fi
#define WIFI_PASSWORD              "matiashenricot" // Setear password

#endif

/*
<html>
    <head>
        <title>Titulo de la ernb que aparece en la pestaña</title>
    </head>
    <body>
        contenido que se ve en pantalla
    </body>

</html>
*/