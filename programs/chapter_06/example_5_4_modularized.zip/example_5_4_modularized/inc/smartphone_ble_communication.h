//=====[#include guards - begin]===============================================

#ifndef _SMARTPHONE_BLE_COMUNICATION_H_
#define _SMARTPHONE_BLE_COMUNICATION_H_

//=====[Libraries]=============================================================

//=====[Declaration of public constants]=======================================

//=====[Declaration of public data types]======================================

//=====[Declarations (prototypes) of public functions]=========================

void smarphoneBleCommunicationWrite( const char* str );

//=====[#include guards - end]=================================================

#endif // _SMARTPHONE_BLE_COMUNICATION_H_