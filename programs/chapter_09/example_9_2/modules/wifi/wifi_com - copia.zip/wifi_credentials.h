#ifndef _WIFI_CREDENTIALS_H_
#define _WIFI_CREDENTIALS_H_

// Define your own Wi-Fi credentials:

//#define WIFI_SSID       "miWifi"     // Setear Red Wi-Fi
//#define WIFI_PASSWORD   "miPassWifi" // Setear password

//#define WIFI_SSID       "Wifi SweetHome"
#define WIFI_SSID       "NISUTA-Home"
#define WIFI_PASSWORD   "CeMaThBe09241727"

#endif // _WIFI_CREDENTIALS_H_

/*
AT+CWJAP="Wifi SweetHome","CeMaThBe09241727"

AT+CWJAP="NISUTA-Home","CeMaThBe09241727"
*/
