//=====[Libraries]=============================================================

#include <arm_book_lib.h>
#include <mbed.h>

#include "sapi.h"     // <= sAPI header
#include "string.h"

#include "esp8266_module.h"

/*==================[macros and definitions]=================================*/

#define PC_SERIAL_COM_BAUD_RATE   115200

/*==================[internal data definition]===============================*/

Serial uartUsb( USBTX, USBRX );

//=====[Main function, the program entry point after power on or reset]========

int main()
{
    parser_t parser;
    parserStatus_t parserStatus;

    tickInit(1); // 1ms tick
    uartUsb.baud(115200);
    esp8266Init();

    uartUsb.printf( "Mando AT.\r\n" );
    delay(1000);

    esp8266Status_t status; 

    while( true ) {

        status = esp8266TestAT();
        
        if( status == ESP8266_OK ) {
            uartUsb.printf( "\r\nOK\r\n" );
            delay(1000);
        } else  if( status == ESP8266_RESPONSE_TIMEOUT ) {
            uartUsb.printf( "\r\nSalio por timeout\r\n" );
        } else if( status != ESP8266_PENDING_RESPONSE ) {
            uartUsb.printf( "esp status = %d\r\n", status );
            delay(1000);
        }

   }

}