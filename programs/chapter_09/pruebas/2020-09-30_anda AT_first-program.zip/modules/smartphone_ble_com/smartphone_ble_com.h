//=====[#include guards - begin]===============================================

#ifndef _SMARTPHONE_BLE_COM_H_
#define _SMARTPHONE_BLE_COM_H_

//=====[Libraries]=============================================================

//=====[Declaration of public defines]=======================================

//=====[Declaration of public data types]======================================

//=====[Declarations (prototypes) of public functions]=========================

void smartphoneBleComWrite( const char* str );

//=====[#include guards - end]=================================================

#endif // _SMARTPHONE_BLE_COM_H_