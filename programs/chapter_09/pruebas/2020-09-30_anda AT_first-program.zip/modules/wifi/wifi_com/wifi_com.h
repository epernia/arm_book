//=====[#include guards - begin]===============================================

#ifndef _WIFI_COM_H_
#define _WIFI_COM_H_

//=====[Libraries]=============================================================

//=====[Declaration of public defines]=========================================

//=====[Declaration of public data types]======================================

//=====[Declarations (prototypes) of public functions]=========================

void wifiComInit();
void wifiComUpdate();

//=====[#include guards - end]=================================================

#endif // _WIFI_COM_H_