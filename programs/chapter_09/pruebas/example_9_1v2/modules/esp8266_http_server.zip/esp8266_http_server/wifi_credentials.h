
#ifndef _WIFI_CREDENTIALS_
#define _WIFI_CREDENTIALS_

// Se deben definir los datos del nombre de la red y la contrasenia.
#define WIFI_SSID                  "Wifi SweetHome" // Setear Red Wi-Fi
#define WIFI_PASSWORD              "CeMaThBe09241727" // Setear password
//#define WIFI_SSID                  "miWifi"     // Setear Red Wi-Fi
//#define WIFI_PASSWORD              "miPassWifi" // Setear password

/*
#if WIFI_SSID == "miWifi" 
#error
*/

#endif