#ifndef _WIFI_DEFAULT_CREDENTIALS_H_
#define _WIFI_DEFAULT_CREDENTIALS_H_

// Define your own Wi-Fi credentials:

//#define WIFI_SSID       "miWifi"     // Setear Red Wi-Fi
//#define WIFI_PASSWORD   "miPassWifi" // Setear password

//#define WIFI_SSID       "Wifi SweetHome"
#define WIFI_SSID       "NISUTA-Home"
#define WIFI_PASSWORD   "CeMaThBe09241727"
//#define WIFI_PASSWORD   "CeMaThBe09241721" // Wrong password

//#define WIFI_SSID       "Speedy-660500"
//#define WIFI_PASSWORD   "F4FEMPT939"

#endif // _WIFI_DEFAULT_CREDENTIALS_H_

/*
AT+CWJAP="Wifi SweetHome","CeMaThBe09241727"
AT+CWJAP="NISUTA-Home","CeMaThBe09241727"
AT+CWJAP="Speedy-660600","F4FEMPT939"
*/
